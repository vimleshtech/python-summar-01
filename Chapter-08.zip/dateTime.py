
import time
t = time.localtime()
print(t)
print(t.tm_year)
print(t.tm_mon)

for i in range(0,5):
     print(i)
     #time.sleep(2)
     


##
from datetime import date
d = date.today()
print(d)


print(d.year)
print(d.month)
print(d.day)
print(d.weekday()) #0-mon , 1 - tue , ...


