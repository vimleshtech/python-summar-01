import os

src =r'C:\Users\vkumar15\Desktop\Weekend - Sessions'
flist = os.listdir(src)

out = open(r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-20thMay\out.txt','w')

for f in flist:
     #print(f)
     if f.endswith('.txt'):
          #print(f)
          #print(src+'\\'+f)
          o = open(src+'\\'+f)
          out.write(o.read())
          out.write('\n--------------------------'+f+'--------------------\n')
          o.close()

out.close()
print('all files compiled to out file')

          
          
          
     


