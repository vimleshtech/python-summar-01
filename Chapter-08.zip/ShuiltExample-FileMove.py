import os
import shutil

src =r'C:\Users\vkumar15\Desktop\Weekend - Sessions'
flist = os.listdir(src)


dest = r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-20thMay'


for f in flist:

     if f.endswith('.txt'):
          shutil.move(src+'\\'+f,dest)
          
          

