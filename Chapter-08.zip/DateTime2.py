import datetime

from datetime import timedelta

x =datetime.datetime.now()
print(x)

t = datetime.datetime.time(x)

print(t)


print(x.strftime("%Y %D %I:%M:%S %p"))
print(x.strftime("%c"))
print(x.strftime("%x"))
      

##
s =timedelta(days=365,hours=30,minutes=45)
print(s)


