#diff of dates
from datetime import date

d0 = date(1990, 8, 18)
d1 = date(2008, 9, 26)

delta = d1 - d0 #enddate - startdate

print(delta)

print (delta.days)


#leapyear
#Check your leap year
year=int(input("Enter year to be checked:"))

if(year%4==0 and year%100!=0 or year%400==0): 
	print("The year is a leap year!") 
else: 
	print("The year isn't a leap year!")

