import mysql.connector as con


c = con.connect(host='localhost',user='root',password='root',database='python_learn')
out = c.cursor()

def read_data():
     out.execute('select * from student')


     o = out.fetchall()
     #print(o)
     for r in o:
          #print(r)
          print(r[0],r[2])


out.execute("insert into student(sid,name) values(10,'Rohit')")
c.commit() #save           




