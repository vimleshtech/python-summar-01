for r in range(1,10):
     print(end='(')
     for c in range(1,r+1):
          if c<r:
               print(c,end='+')
          else:
               print(c,end='')
     print(end=')+')
          


#pattern
for r in range(1,10):     
     for c in range(1,r+1):
          print('*',end='')
     print() #new line
     
          
#reverse
for r in range(1,10):
     for c in range(10,r,-1): #from 10 to 1   , -1
          print('*',end='')
     print()
     
