
st = input('enter string ')

print(st.upper())
print(st.lower())
print(st.title())
print(st.strip())
print(st.replace('a','xy'))
print(st.count('a'))

print(list(st))

x = st.split(' ')
print(x)


if st.endswith('y'):
     print('ending with y')
else:
     print('not ending with y')
     
           
      
