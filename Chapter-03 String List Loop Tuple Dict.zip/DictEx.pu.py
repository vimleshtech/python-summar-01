#dict

d ={'a':'alpha',1:'one',2:'two',101:[11,222,'nitin']}

print(d)

i = input('enter key to search :')

print(d[i])

#add new key
d['t'] = 'tata' #here t is new key

#modify
d['a'] ='test modify'

print(d)

