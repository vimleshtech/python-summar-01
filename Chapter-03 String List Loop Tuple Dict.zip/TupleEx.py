wdays = ('mon','tue','wed','thu','sat')

day = input('enter day name :')

if day in wdays:
     print('entry allowed ...')
else:
     print('plz go back to home..today is off day ')

     

