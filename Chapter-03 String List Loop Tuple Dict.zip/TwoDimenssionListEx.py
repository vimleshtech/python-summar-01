#declare two D. list 
a = [[1,'nitin','male'],[2,'raman','male'],[3,'monkia','female']] #2d list

print(a) #print all


for r in a:
     #print(r,end=' ')
     print(r)


#
for r in a:
     for c in r:
          print(c)
          
     

#dynamic two D. list
emp  = []
for r in range(1,4):
     c = []
     eid  = input('enter eid  ')
     ename  = input('enter name  ')
     esal  = int( input('enter sal  '))
     c.append(eid)
     c.append(ename)
     c.append(esal)
     emp.append(c)


print(emp)



     
     


     
     
     





     
                   
                   
