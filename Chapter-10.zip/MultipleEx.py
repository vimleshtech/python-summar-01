#multipe
class x:
     def ex1(s):
          print('x')

class y:
     def ex2(s):
          print('y ')

class z(x,y): #multiple
     def ex3(s):
          print('z')


#
o =z()
o.ex1()
o.ex2()
o.ex3()
     

