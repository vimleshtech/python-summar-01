#python doesn't support overloading, by default this will overwrite the data or function

a =11
a ='aa'

print(a)


##
def add(a,b):
     c =a+b
     print(c)
     

def add(a,b,c):
     d =a+b+c
     print(d)
     

#call
#add(11,2) #error
add(11,22,4)

     
