class student:
     
     def input_data(s):
          s.roll =  int(input('enter roll no :'))
          s.name=  input('enter name :')
          #s.add=  input('enter address :')
          #s.city=  input('enter city :')
          #s.country=  input('enter country :')


     def retroll(s):
          return s.roll
     
     def disp_data(s):
          print('Roll No: ',s.roll, end='|')
          print('Roll Name: ',s.name)
          #print('Roll Address: ',s.add)
          #print('Roll City: ',s.city)
          #print('Roll Country: ',s.country)

#empty list
s = []
for i in range(0,5):
     obj = student()
     obj.input_data()
     s.append(obj)  #store object(with data) in list

#print list (this will print/show the objects)
print(s)


#sorting
for i in range(0,5):
     for j in range(i+1,5):
          if s[i].retroll() > s[j].retroll():
               temp = s[i]
               s[i] = s[j]
               s[j] = temp

#show  all data
for o in s:
     o.disp_data()


#find by roll number
rn = int(input('enter roll number to search :'))
for o in s:
     if o.retroll() == rn:
          o.disp_data()
          




     


     





          
               
                    




               
          
          
     
     

     
  

     
     








          
          
     
     
