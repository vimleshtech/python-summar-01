class a:
     def add(s,a,b):
          print(a+b)

     def sub(s,a,b):
          print(a-b)



class b(a):
     def mul(s,a,b):
          print(a*b)


class c(b):
     def div(s,a,b):
          print(a/b)

     

'''          
o = b()
o.add(11,3)
o.mul(23,4)
'''
o =c()
o.add(11,3)
o.mul(11,3)
o.div(11,3)






     
