import re


s = input('enter string ')
o = re.match('(.*) are (.*)',s)

#print(o.groups())

if o:
     print('are is matched')
else:
     print('are is not matched')

     

#use case : validate the gmail account
email = input('enter gmail email id:')

r = re.search('@gmail.com$',email)
if r:
     print('correct email id')
else:
     print('incorrect')
     





