a =['a','e','i','o','u']

x = input('enter data :')
vo = 0
dc = 0
for c in x:
     if c in a:
          vo+=1
     elif c.isdigit():
          dc+=1
        
print(vo)
print(dc)

          
     
