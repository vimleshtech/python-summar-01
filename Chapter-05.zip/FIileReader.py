     
#default mode of open/file is read
o = open(r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-20thMay\notes.txt')
#print(o)

#print(o.read())

#print(o.readline())
#print(o.readline())

data = o.readlines()

o.close() #close the file 

#print(type(data))

#print(data)
#wap to get row count
#wap to get char counts
#wap to get word count
#wapt to get count of given word(find the word')

cc = 0
wc = 0
pwc = 0

for r in data:
     print(r)
     col = r.split() #here col is list
     wc+= len(col)
     cc += len(r)

     for w in col:
          if w=='is':
               pwc+=1

     
     
print('row count ',len(data))
print('char count ',cc)
print('word count ',wc)
print('is count ',pwc)







