n  = int(input('enter nu :'))
d  = int(input('enter nu :'))

#
try:
     if d<0:
          er = ZeroDivisionError('divisor cannot be less than 0')
          raise er
     o = n/d
     print('div :',o)
     
except NameError as a:
     print(a)
except ZeroDivisionError as e:
     print(e)     
except:
     print('div is fail')
     #pass     
finally:
     print('in finally')
     
#add
o =n+d
print("sum :",o)

