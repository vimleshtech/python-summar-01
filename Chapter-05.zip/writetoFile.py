#w : create new file if not exist
#  : overwrite the file if exist

o = open(r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-20thMay\out.txt','w')
o.write('1\n')
o.write('hi'+'\n')
o.write('hello'+'\n')
o.write('test\n')

o.close()
print('file is saved')






     
