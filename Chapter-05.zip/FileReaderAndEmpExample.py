o = open(r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-20thMay\emp.txt','r')

data =o.readlines()
fc =0
mc =0

for r in data:
     col = r.split(',')
     print(col)
     if col[2] =='male':
          mc+=1
          
     elif col[2] =='female':
          fc+=1

print('male count ',mc)
print('female count ',fc)

          
     


