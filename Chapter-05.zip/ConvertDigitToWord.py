w1 = ['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen']
w2 = ['','','twenty','thirty','foruty','fifty','sixty','seventy','eighty','ninty']

n = int( input('enter data :'))
if n< 20:
     print(w1[n])
elif n<100:
     n1 = n//10 #int  23/10 = 2.3 , 23//10 = 2
     n2 = n% 10 # 23%10 = 3

     if n2>0:
          print(w2[n1],w1[n2])
     else:
          print(w2[n1])
elif n<1000:
     n1 = n//100 # 786 // 100 = 7
     n2 = n%100
     print(w1[n1],'hundered',end=' ')

     n = n2
     n1 = n//10 #int  23/10 = 2.3 , 23//10 = 2
     n2 = n% 10 # 23%10 = 3

     if n2>0:
          print(w2[n1],w1[n2])
     else:
          print(w2[n1])
          

     

     





     
     
     
     
     
     


          




