
for x in range(100,999):
     n1 = x//100
     n2 = (x%100)//10
     n3 = x%10

     if n1**3+n2**3+n3**3 == x:
          print('Armstrong no :',x)


#
a ="RAJAT"
'''
RAJAT
RAJA
RAJ
..

'''
for i in range(0,len(a)):
     for c in range(0,len(a)-i):
          print(a[c],end='')
     print()
     






     
