
a = int(input('enter first no :'))
b = int(input('enter first no :'))

a=a**2

if a==b:
     print('equal ')
else:
     print('not equal ')



print('a'*100000)

     
     
     
     
