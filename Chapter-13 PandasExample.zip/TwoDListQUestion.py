data = [[11,22],[1,33],[66,7]]

for i in range(len(data)): #from 0 to len-1
     #print(data[i])
     for c in range(i+1,len(data)):
          if data[i][0] > data[c][0]:
               t = data[i]
               data[i] =data[c]
               data[c] =t


print(data)
print('highest value :',data[-1][0])

          
          
     
     
