import pandas as pd


#create dataframe from table
eid =[11,22,33,44]
name =['Raman','Jatin','Divya','Ayush']
gender =['M','M','F','M']
sal = [40000,80000,65000,14000]
exp = [4,2,6,1]

df = pd.DataFrame(data={'eid':eid,'ename':name,'gender':gender,'sal':sal,'exp':exp})

print(df)


#info
print(df.info())


#
print(df.describe())

#sorting : arrange data in asc or desc
print(df.sort_values('sal',ascending=True))
print(df.sort_values('sal',ascending=False))


print(df.sort_values('ename',ascending=False))

#by multiple columns
print(df.sort_values(['gender','sal'],ascending=[True,False]))

#corr
print(df.corr())


###
d = df.values
print(d)

#
print(d[:2,:])  # row index, and col index
print(d[1:4,1:3])

#where
print(df[df['sal']>40000])







      



