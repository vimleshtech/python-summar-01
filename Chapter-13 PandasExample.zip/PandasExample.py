import pandas as pd


#create empty datafame

df = pd.DataFrame()
print(df)

#index: rows
#columns : header



#create dataframe from table
eid =[11,22,33,44]
name =['Raman','Jatin','Divya','Ayush']
gender =['M','M','F','M']
sal = [111111,2222,34333,4444]

df = pd.DataFrame(data={'eid':eid,'ename':name,'gender':gender,'sal':sal})
print(df)

#
print(df.shape)

print(df.head(2)) #return top given rows
print(df.tail(1)) #return buttom given rows


#print particular column
print(df['ename']) #return one column

print(df[['ename','gender']]) #return multiple column


#group by
print(df.groupby('gender').size())
print(df.groupby('gender').max())
print(df.groupby('gender').min())
print(df.groupby('gender').sum())
print(df.groupby('gender').sum()['sal'])

print( df.corr())  #stats

print( df.describe())


df.to_csv('out.csv')

















