class Test:

     def add(s,a,b): #first argument is ref of object
          print(s)
          s.c =a+b #c is local var, now s.c is global of class
     def show(ad):
          print(ad.c)
          
     def __init__(s,b):
          print('object is created ',b)
          

     def __del__(s):
          print(s, ' is removed')
          


#create object
o = Test('a')
print(o)
o.add(11,3)
o.show()

del o
o.show()


