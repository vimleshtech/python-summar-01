a = input('enter data :')


out = []
for c in a:
     x = ord(c)
     #print(x,end='')
     out.append(x)

i = 1
for c in out:
     if i % 2 ==0:

          print(c*100,end='')
     else:
           print(str(c)+'11aaaa000',end='')

     i+=1

print()
for c in out:
     print(chr(c),end='')
     

