s ='    '
for i in range(1,6):
     print(s[:len(s)-(i-1)],end='')

     
     for j in range(1,i+1): #1  - 3 <4          
               print(i,end=' ')
          
               
          
     print()
          
     
