data = [[1,2,3],[3,5,5]]

print(data) #print all data  
print(data[0]) #print first row 
print(data[1]) #prind 2nd row

print(data[0][0]) #print first row and first col
print(data[0][1]) #print first row and 2nd col

print(len(data)) #print row len

print(len(data[0])) #print col len

#iterate
for r in data: #table to row 
     #print(r)
     for c in r: #row to col/cell/value
          print(c)
          
#dynamic 2D list
stu = []

for i in range(2):
     
     sid = int(input('enter eid '))
     name = input('enter name ')
     hs = int(input('enter hs '))
     es = int(input('enter es '))
     cs = int(input('enter cs '))
     ms = int(input('enter ms '))
     
     stu.append([sid,name,hs,es,cs,ms]) #add data to list


print(stu)


for r in stu:
     t =r[2]+r[3]+r[4]+r[5]
     a = t/4
     
     print(r[0], r[1], t, a)












          
     

