
'''
CRUD : create, read , update , delete operations
'''

data = []

while True:
     ch = input('enter 1 for add 2 for show 3 for update 4 for delete 0 for exit')
     if ch =='1':
          d = input('enter data :')
          data.append(d)
     elif ch =='2':
          #print(data)
          for x in data:
               print(x)
     elif ch =='3':
          d = input('enter existing value :')
          
          i  =0
          while i<len(data):
               if d == data[i]:
                    nv = input('enter new value:')
                    data[i] = nv                    
               i=i+1 #i+=1
               
     elif ch =='4':
          d = input('enter existing value to remvoe:')
          if d in data:
               data.remove(d)
          else:
               print('value is not found')
     elif ch =='0':
          break
     else:
          print('invalid choice , try again !!!')

          
     
          
          
               
     

     

     
