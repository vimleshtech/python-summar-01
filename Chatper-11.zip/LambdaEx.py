
y = lambda x: x+1

'''
def y(x):
     x =x+1
     return x
'''

print(y(1))
print(y(10))



#
def add(a,b):
     print(a+b)

def add(a,b=0,c=0):  #default value
     print(a+b+c)


##dynamic arguments
def mul(*a): #default type of argument, tuple
     print(a)
     x =1 
     for d in a:
          x*=d
     print(x)
     
     

add(11,2,2)
add(11,2)
add(11)

mul(111,23,3,4,45,56)
mul(111,23,3,4,45,56,5,3,3,3,4,5,6,4)
     



