import numpy as np

l = [11,22,3,4]
print(type(l))
print(l)
print(l*2)


#create array from list 
d = np.array(l)
print(type(d))
print(d)
print(d*2)

#one dimenssion 
arr = np.array([1111,22,3,4,5])
print(arr)

#print  dimenssion and count
print(arr.shape)

#multi dimenssion array 
arr = np.array([[1,2,3],[4,5,6],[5,6,7],[55,66,77]])
print(arr)
print(arr.shape)


#functions
print(np.zeros(10))
print(np.ones(10))


#data type
arr = np.array([1111,22,3,4.44,5.23],dtype='float')
print(arr)




# Convert to 'int' datatype
arr = np.array([1111.22,22.44,3])
o = arr.astype('int')
print(o)


# Create a boolean array
arr2d_b = np.array([1, 0, 10], dtype='bool')
print(arr2d_b)


##convert arary to list
d = np.array(l)

x = d.tolist()
print(type(x))


# Extract the first 2 rows and columns
arr = np.array([[1,2,3],[4,5,6],[5,6,7],[55,66,77]])
o  = arr[:2, :2] #row 0 to <2, col 0<2 dimenssion
print(o)



o  = arr[2:4, :2] #row 2 to <4    , col 0<2 dimenssion
print(o)























