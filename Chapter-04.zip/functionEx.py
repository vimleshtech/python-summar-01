def wel():
     print('this is welcome function ...')

def get_input():
     a = input('enter data :')
     b = input('enter data :')
     return a,b

def add(a,b):
     c =a+b
     print(c)

#Argument with return 
def mul(a,b):
     c = a*b
     return c

#Function with optional argument
def add2(a,b=0,c=0,d=0):
     x = a+b+c
     print(c)

#FUnction with dynamic argument
def mul(*arg): #type of arg is tuple
     print(arg)
     print(type(arg))
     o =1
     for x in arg:
          o*=x # o = o*x

     print(o)
     
     
#recursive fun
def fact(n):
     if n ==1 :
          return n
     else:
          return n*fact(n-1)
     
     

     

#call to function
wel()
x,y = get_input()
print(x+y)

add(11,323) #error 
o = mul(11,2)
print(o)


add2(11,2)
add2(44,55,6)
add2(4,5,66,7)


mul(11,22,3,4,5)
mul(11,22,3,4,5,5,6,4,34,3)
mul(11,22,3,4,5,44,3,2,2,2,3,3,3,32,2,2)

mul()

o = fact(5)
print(o)



