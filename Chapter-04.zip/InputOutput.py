n1 = input('enter data :')
n2 = input('enter data :')

n = int(n1)+ int(n2)

print(n)
