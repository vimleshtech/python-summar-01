#import module
import taxCal

taxCal.gst(2344)
amt = int(input('enter bsal :'))

taxCal.income_tax(amt)


#or
import taxCal as t
t.gst(4555)



#or
from taxCal import *
gst(33344)



#or
from taxCal import income_tax,gst
income_tax(33344)

#
import math
print(math.sqrt(9))


     
