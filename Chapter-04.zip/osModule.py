import os

f= os.listdir(r'C:\Users\vkumar15\Desktop\Desktop - Raman')

print(f)

for x in f:
     print(x)
     
