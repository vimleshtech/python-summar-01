
def gst(amt):
     
     if amt<5000:
          cgst = amt*.025
          sgst = amt*.025
     else:
          cgst = amt*.06
          sgst = amt*.06

     print('cgst is :',cgst)
     print('sgst is :',sgst)


def income_tax(sal): #basic sal
     hra = sal*.40
     da = sal*.20
     travel = 2000

     msal = sal+hra+da+travel

     ysal = msal*12
     
     if ysal<500000:
          tax = 0
     elif ysal<1000000:
          tax = 12500 +(ysal-500000)*.20
     else:
          tax = 112500 +(ysal-1000000)*.30

     print('total income tax is:',tax)
     


          


          
          



          
     
     
     
