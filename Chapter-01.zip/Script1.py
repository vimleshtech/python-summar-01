a =55
b =55

#addition 
c = a+b
print('sum of two numebrs :',c)


#sub
c =a-b
print('sub of two numebers :',c)

#mul
c =a*b
print('mul of two numebers :',c)

#div
a = 12/10
print('div :',a)

#//
a = 12//10
print('div :',a)



#%
a = 12%10
print('mod :',a)


#
a = 2+3*4
print(a)

a = (2+3)*4
print(a)





