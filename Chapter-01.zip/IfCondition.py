#if example
amt = int(input('enter sales amt :'))

tax = 0
if amt>1000:
     tax = amt*.18


total = amt+tax
print('total amt is :',total)

