#if elif elif... else example
a = int(input('enter num  :'))
b = int(input('enter num  :'))
c = int(input('enter num  :'))

if a>b and a>c:
     print('a is gt')
elif b>a and b>c:
     print('b is gt')
else:
     print('c is gt')

     
