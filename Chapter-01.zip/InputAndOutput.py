a = int(input('enter num 1 :'))
b = int(input('enter num 2 :'))


'''
print(type(a))
print(type(b))

#type casting / type conversion
a = int(a)
b = int(b)
'''

c = a+b
print('sum of two numpers :',end='\t')
print(c)

