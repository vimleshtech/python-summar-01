import pandas as pd

d = pd.read_csv('out.csv')
print(d)


#pd.read_excel()



